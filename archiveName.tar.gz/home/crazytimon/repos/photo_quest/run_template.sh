export TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here
docker compose up --build
