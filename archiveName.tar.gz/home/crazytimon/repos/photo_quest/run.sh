export TELEGRAM_BOT_TOKEN=7156679619:AAEwwOlSOLKd5FOqek7-YyyVW9-LYTm1Eg0
docker compose up --build -d
