export const HOST = 'http://192.168.31.36'
export const BE_PORT = 3000
export const FULL_URL = `${HOST}:${BE_PORT}`