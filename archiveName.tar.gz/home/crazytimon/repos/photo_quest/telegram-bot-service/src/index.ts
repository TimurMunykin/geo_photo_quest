import dotenv from 'dotenv';
dotenv.config();

import './telegramBot';
console.log("Telegram bot service started");
